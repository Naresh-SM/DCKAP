<?php
    include("inc/dbconn.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Report</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <?php include("inc/header.php");?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php include("inc/sidebar.php");?>  
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Report </h3>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Gender Report</h4>
                    </p>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> Gender </th>
                          <th> Total Customers </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                            $sql2 = "SELECT COUNT(gender) AS total_male FROM customer_list WHERE gender='1'";
                            $result2 = $conn->query($sql2);
                            $row2 = $result2->fetch_assoc();

                            $total_male = $row2['total_male'];

                            $sql2 = "SELECT COUNT(gender) AS total_female FROM customer_list WHERE gender='2'";
                            $result2 = $conn->query($sql2);
                            $row2 = $result2->fetch_assoc();

                            $total_female = $row2['total_female'];
                        ?>
                        <tr>
                            <td>Male</td>
                            <td><?php echo $total_male;?></td>
                        </tr>
                        <tr>
                            <td>Female</td>
                            <td><?php echo $total_female;?></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Zip Code Report</h4>
                    </p>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> Sno </th>
                          <th> Zip Code </th>
                          <th> Total Customers </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                            $sql = "SELECT * FROM customer_list GROUP BY zip_code";
                            $result = $conn->query($sql);
                            $count = 1;
                            while ($row = $result->fetch_assoc()) {
                                $zip_code = $row['zip_code'];

                                $sql1 = "SELECT COUNT(zip_code) AS total_count FROM customer_list WHERE zip_code='$zip_code'";
                                $result1 = $conn->query($sql1);
                                $row1 = $result1->fetch_assoc();
                                ?>
                                    <tr>
                                        <td><?php echo $count++;?></td>
                                        <td><?php echo $row['zip_code'];?></td>
                                        <td><?php echo $row1['total_count'];?></td>
                                    </tr>
                                <?php
                            }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="footer-inner-wraper">
              <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © bootstrapdash.com 2020</span>
              </div>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
  </body>
</html>