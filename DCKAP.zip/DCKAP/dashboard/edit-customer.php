<?php
    include("inc/dbconn.php");

   $message = $_REQUEST['msg'];
   $id = $_REQUEST['id'];

   $sql = "SELECT * FROM customer_list WHERE id='$id'";
   $result = $conn->query($sql);
   if($result->num_rows > 0)
   {
        $row = $result->fetch_assoc();
   }else{
       header("Location: all-customer.php?msg=Invalid!");
   }

    if(isset($_POST['submit']))
    {
        $name = $_POST['name'];
        $last_name = $_POST['last_name'];
        $mobile_number = $_POST['mobile_number'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $address = $_POST['address'];
        $zip_code = $_POST['zip_code'];

        $sql = "SELECT * FROM customer_list WHERE (mobile_number='$mobile_number' OR email='$email') AND id!='$id'";
        $result = $conn->query($sql);
        if($result->num_rows == 0)
        {
          $sql = "UPDATE customer_list SET first_name='$name',last_name='$last_name',mobile_number='$mobile_number',email='$email',gender='$gender',address='$address',zip_code='$zip_code'";
          if($conn->query($sql) == TRUE)
          {
            header("Location: all-customer.php?msg=Updated!");  
          }
          else
          {
            header("Location: all-customer.php?msg=Failed!");
          }
        }
        else
        {
          header("Location: all-customer.php?msg=Phone Number or Email exist!");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Add Customer</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="assets/vendors/select2/select2.min.css">
    <link rel="stylesheet" href="assets/vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <?php include("inc/header.php");?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php include("inc/sidebar.php");?>  
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Customer </h3>
            </div>
            <div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Edit Customer</h4>
                    <form class="forms-sample" method="POST">
                      <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" class="form-control" id="name" placeholder="Name" value="<?php echo $row['first_name'];?>">
                      </div>
                      <div class="form-group">
                        <label for="last_name">Last Name</label>
                        <input type="text" name="last_name" class="form-control" id="last_name" placeholder="Last Name" value="<?php echo $row['last_name'];?>">
                      </div>
                      <div class="form-group">
                        <label for="mobile">Mobile</label>
                        <input type="text" name="mobile_number" class="form-control" id="mobile" placeholder="Mobile" value="<?php echo $row['mobile_number'];?>">
                      </div>
                      <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" class="form-control" id="email" placeholder="Email" value="<?php echo $row['email'];?>">
                      </div>
                      <div class="form-group">
                        <label for="gender">Gender</label>
                        <select class="form-control" name="gender" id="gender">
                          <option selected value disabled>Select Gender</option>
                          <?php
                            if($row['gender'] == 1)
                            {
                                $male = "selected";
                            }
                            else{
                                $female = "selected";
                            }
                          ?>
                          <option value="1" <?php echo $male;?>>Male</option>
                          <option value="2" <?php echo $female;?>>Female</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="address">Address</label>
                        <textarea name="address" id="address" cols="30" rows="10" placeholder="Address" class="form-control"><?php echo $row['address'];?></textarea>
                      </div>
                      <div class="form-group">
                        <label for="zip_code">Zip Code</label>
                        <input type="text" name="zip_code" class="form-control" id="zip_code" placeholder="Zip Code" value="<?php echo $row['zip_code'];?>">
                      </div>
                      <input type="submit" name="submit" class="btn btn-primary mr-2" onclick="return validate()" value="Submit">
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="footer-inner-wraper">
              <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © bootstrapdash.com 2020</span>
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> Free <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap dashboard templates</a> from Bootstrapdash.com</span>
              </div>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/select2/select2.min.js"></script>
    <script src="assets/vendors/typeahead.js/typeahead.bundle.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <script src="assets/js/manual.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <script src="assets/js/typeahead.js"></script>
    <script src="assets/js/select2.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>