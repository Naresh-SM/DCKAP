function validate() {
    let name = document.getElementById('name');
    let last_name = document.getElementById('last_name');
    let mobile = document.getElementById('mobile');
    let email = document.getElementById('email');
    let gender = document.getElementById('gender');
    let address = document.getElementById('address');
    let zip_code = document.getElementById('zip_code');

    if(name.value == "") {
        name.style.border = "1px solid red";
        return false;
    }else {
        name.style.border = "1px solid rgba(151, 151, 151, 0.3)";
        
        if(last_name.value == "") {
            last_name.style.border = "1px solid red";
            return false;
        }else {
            last_name.style.border = "1px solid rgba(151, 151, 151, 0.3)";
            
            if(mobile.value == "") {
                mobile.style.border = "1px solid red";
                return false;
            }else {
                mobile.style.border = "1px solid rgba(151, 151, 151, 0.3)";

                if(email.value == "") {
                    email.style.border = "1px solid red";
                    return false;
                }else {
                    email.style.border = "1px solid rgba(151, 151, 151, 0.3)";

                    if(gender.value == "") {
                        gender.style.border = "1px solid red";
                        return false;
                    }else {
                        gender.style.border = "1px solid rgba(151, 151, 151, 0.3)";

                        if(address.value == "") {
                            address.style.border = "1px solid red";
                            return false;
                        }else {
                            address.style.border = "1px solid rgba(151, 151, 151, 0.3)";

                            if(zip_code.value == "") {
                                zip_code.style.border = "1px solid red";
                                return false;
                            }else {
                                zip_code.style.border = "1px solid rgba(151, 151, 151, 0.3)";
                                return true;
                            }
                        }
                    }
                }
            }
        }
    }
}