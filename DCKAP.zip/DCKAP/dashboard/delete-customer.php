<?php
    include("inc/dbconn.php");
    $id = $_REQUEST['id'];

    $sql = "SELECT * FROM customer_list WHERE id='$id'";
    $result = $conn->query($sql);
    if($result->num_rows > 0)
    {
        $sql = "DELETE FROM customer_list WHERE id='$id'";
        if($conn->query($sql)==TRUE)
        {
            header("Location: all-customer.php?msg=Deleted!");
        }
    }else{
        header("Location: all-customer.php?msg=Invalid!");
    }

?>