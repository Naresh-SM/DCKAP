<?php
    ini_set('display_errors', 'off');
    $host = "localhost";
    $username = "root";
    $password = "";
    $db_name = "dckap";
    $conn = mysqli_connect($host,$username,$password);
    mysqli_select_db($conn,$db_name) or die("Under Maintanance");

?>